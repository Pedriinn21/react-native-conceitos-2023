import React from 'react'
import { Button, Text } from 'react-native'

const Botoes = () => {
  return (
    <>
    <Button
  title="Learn More"
  color="#841584"
  accessibilityLabel="Learn more about this purple button"/>

<Button
  title="Learn More"
  color="red"
  accessibilityLabel="Learn more about this purple button"/>


    </>
  )
}

export default Botoes